 
Datotaka s kodo: ICA_artefact_exclusion.ipynb
je formata Jupyter notebook. Za odpiranje datoteke je potreben
python s knjižnico jupyter.